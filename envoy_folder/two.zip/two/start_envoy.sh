#!/bin/bash
set -e

fx envoy start -n env_two --disable-tls -d nnlicv838.inn.intel.com:50051